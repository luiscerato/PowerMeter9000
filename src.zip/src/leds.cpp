#include "leds.h"
#include "pins.h"


Freenove_ESP32_WS2812 ledStrip = Freenove_ESP32_WS2812(5, pinPixelLed, 1);

void begin()
{

}
#ifndef LEDS_C_
#define LDES_C_

#include "Arduino.h"
#include "Freenove_WS2812_Lib_for_ESP32.h"

void begin();

#endif